import express from 'express';
import line from '@line/bot-sdk';
import axios from 'axios';
console.log(123)
import fs from 'fs';
import OpenAI from 'openai';

// 注意！以下兩行需替換為 ES Module 的環境變數讀取方式
const config = {
  channelAccessToken: process.env.CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.CHANNEL_SECRET,
};

const app = express();
app.use('/webhook', express.raw({ type: '*/*' }));

const client = new line.Client(config);

// // ✅ OpenAI 初始化
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// ✅ 讀取標準書文件（需確認檔案路徑）
const standardDoc = fs.readFileSync(new URL('./standard.txt', import.meta.url), 'utf8');

// 判斷是否為員工編號
function isEmployeeId(text) {
  return /^\d{5}$/.test(text.trim());
}

// Webhook handler
app.post('/webhook', line.middleware(config), async (req, res) => {
  try {
    const events = req.body.events;
    const results = await Promise.all(events.map(handleEvent));
    res.json(results);
  } catch (err) {
    console.error('Webhook 錯誤:', err);
    res.status(500).end();
  }
});

// 處理單一事件
async function handleEvent(event) {
  if (event.type !== 'message' || event.message.type !== 'text') {
    return null;
  }

  const text = event.message.text.trim();
  const userId = event.source.userId;

  if (isEmployeeId(text)) {
    // ✅ 員工驗證流程
    try {
      const response = await axios.post(process.env.GOOGLE_SHEET_WEBAPP_URL, {
        userId,
        employeeId: text
      });
      const result = response.data;

      const replyMsg = result.success
        ? `✅ 驗證成功，歡迎您，${result.name}！`
        : '❌ 查無此員工編號，請重新確認後輸入。';

      return client.replyMessage(event.replyToken, {
        type: 'text',
        text: replyMsg
      });
    } catch (err) {
      console.error('員工驗證失敗:', err);
      return client.replyMessage(event.replyToken, {
        type: 'text',
        text: '⚠️ 員工驗證時發生錯誤，請稍後再試。'
      });
    }
  } else {
    // ✅ ChatGPT Assistants API 查詢
    try {
      const thread = await openai.beta.threads.create();

      await openai.beta.threads.messages.create(thread.id, {
        role: 'user',
        content: text
      });

      const run = await openai.beta.threads.runs.create(thread.id, {
        assistant_id: process.env.OPENAI_ASSISTANT_ID
      });

      let runStatus;
      let attempts = 0;
      do {
        console.log(1);
        await new Promise(resolve => setTimeout(resolve, 60000));
        runStatus = await openai.beta.threads.runs.retrieve(thread.id, run.id);
        console.log(2, runStatus);
        attempts++;
      } while (runStatus.status !== 'completed' && attempts < 20);

      if (runStatus.status !== 'completed') {
        throw new Error('Assistant 回覆逾時');
      }

      const messages = await openai.beta.threads.messages.list(thread.id);
let replyMsg = '⚠️ Assistant 沒有回覆內容。';

if (messages && Array.isArray(messages.data)) {
  const assistantMessage = messages.data.find(m => m.role === 'assistant');
  if (
    assistantMessage &&
    Array.isArray(assistantMessage.content) &&
    assistantMessage.content[0] &&
    assistantMessage.content[0].type === 'text' &&
    assistantMessage.content[0].text &&
    typeof assistantMessage.content[0].text.value === 'string'
  ) {
    replyMsg = assistantMessage.content[0].text.value;
  }
}
      return client.replyMessage(event.replyToken, {
        type: 'text',
        text: replyMsg
      });
    } catch (err) {
      console.error('ChatGPT Assistants API 錯誤:', err);
      return client.replyMessage(event.replyToken, {
        type: 'text',
        text: '⚠️ 系統忙碌中，請稍後再試。'
      });
    }
  }
}

// 測試頁面
app.get('/test', async (req, res) => {
  const dummy = '93045';
  try {
    const response = await axios.post(process.env.GOOGLE_SHEET_WEBAPP_URL, {
      employeeId: dummy
    });
    res.json({
      testedEmployeeId: dummy,
      sheetResult: response.data
    });
  } catch (err) {
    res.status(500).json({ error: err.toString() });
  }
});

app.listen(3000, () => {
  console.log("Running Node version:", process.version);
  console.log('🤖 智能客服機器人已啟動...');
});